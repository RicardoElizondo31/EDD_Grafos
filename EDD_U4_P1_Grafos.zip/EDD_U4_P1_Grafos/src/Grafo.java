/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class Grafo {
    NodoVertice vertice;
    NodoVertice Ini;
    NodoVertice Fin;
    int i=0;
    
    public Grafo(){
        vertice = null;
    }
    
    
    //Codigo insertar vertice
    public boolean insertarVertice(char dato){
        NodoVertice nuevo = new NodoVertice(dato);
        if(nuevo == null)return false;
        
        if(vertice == null){
            vertice = nuevo;
            i++;
            return true;
        }
        
        irUltimo();
        vertice.sig = nuevo;
        nuevo.ant = vertice;
        i++;
        return true;        
    }

    private void irUltimo() {
       while(vertice.sig != null){
           vertice = vertice.sig;       
       }
    }
    
    private void irPrimero(){
        while(vertice.ant != null){
            vertice = vertice.ant;
        }
    }
   
    
    //Codigo Buscar vertice
    private NodoVertice buscarVertice(char dato){
        if(vertice == null) return null;
        irPrimero();
        
        for(NodoVertice buscar = vertice; buscar != null; buscar = buscar.sig){
            if(buscar.dato == dato){
                return buscar;
            }
        }
        return null;
    }
    
    
    
    //Codigo insertar arista
    public boolean insertarArista(char origen, char destino){
        NodoVertice Origen = buscarVertice(origen);
        NodoVertice Destino = buscarVertice(destino);
        
        if(Origen == null || Destino == null){
            return false;
        }
        return Origen.insertarArista(Destino);
    }
    
    
    
    //Codigo eliminar 
    public boolean eliminarArista(char origen, char destino){
        NodoVertice Origen = buscarVertice(origen);
        NodoVertice Destino = buscarVertice(destino);
        if(Origen == null || Destino == null){
            return false;
        }
        return Origen.eliminarArista(Destino);
    }
    
    public boolean unSoloVertice(){
        return vertice.ant == null && vertice.sig == null;
    }
    
    
    
    //codigo eliminar vertice
    public boolean elminarVertice(char dato){
        if(vertice == null) return false;
        NodoVertice temp = buscarVertice(dato);
        if(temp == null) return false;
        
        //Debemos que verificar que el vertice sea una isla
        
        //Verificar que no tenga aristas
        if(temp.arista != null)return false;
        //Verifica que no reciba aristas
        eliminarArista(temp);
        //esta temp en el primero
        if(temp == vertice){
            if(unSoloVertice()) vertice = null;
            else{
                vertice = temp.sig;
                temp.sig.ant = temp.sig = null;
            }
            i--;
            return true;
        }
        //esta en el ultimo
        if(temp.sig == null){
            temp.ant.sig = temp.ant = null;
            i--;
            return true;
        }
        //temp esta en medio
        temp.ant.sig = temp.sig;
        temp.sig.ant = temp.ant;
        temp.sig = temp.ant = null;
        i--;
        return true;
    }

    private void eliminarArista(NodoVertice NodoEliminar) {
        irPrimero();
        for(NodoVertice buscar  = vertice; buscar != null; buscar = buscar.sig){
            buscar.eliminarArista(NodoEliminar);
        }
    }
    
    
    
    
    //Construccion de la matriz de adyacencia
    public String matrizAdyacencia(){ 
        
        if(vertice == null) return null;
          String[][] m = new String [i][i];
            for(int d=0; d<m.length; d++){
                for(int o=0; o<m.length; o++){
                m[d][o]=0+"";
                }   
            }
            irPrimero();
            for(int t = 0; t<m.length; t++){
                for(int s = 0; t<m.length; s++){
            if(vertice.arista == null){
                t++;
                s=0;
                vertice = vertice.sig;
            }else{
                m[t][s] ="1";
                vertice.arista = vertice.arista.abajo; 
            }    
           }   
          }     

        return mostrarMatriz(m);
    }
    
    
    
    //Codigo mostrar matriz
    public String mostrarMatriz(String[][] cad){
        String cadena="";
        for(int d=0; d<cad.length; d++){
                for(int o=0; o<cad.length; o++){
                    cadena+= cad[d][o]+",";
                }
                cadena+="\n";
        }
        return cadena;
    }
    
    
    
    public String ListaAdyacencia(char dato){
        NodoVertice N = buscarVertice(dato);
        String Cadena = "";
        if(N.arista == null){  // no hay aristas en el vertice
            Cadena = "Nodo: " + N.dato + "\n"+ "No tiene aristas";
            return Cadena;
        }
        
        if(N.arista.abajo == null){ // una sola arista en el vertice
            Cadena = "Nodo: "+  N.dato+"\n - "+N.arista.direccion.dato+" -";
            return Cadena;
        }
        
        Cadena+="Nodo: "+N.dato+"\n- ";
        
        for(NodoArista temp = N.arista; temp != null; temp = temp.abajo){ // mas de una aristaaaa
            
            Cadena += temp.direccion.dato+" - ";
            
        }
       return Cadena;
    }
    
    
}

